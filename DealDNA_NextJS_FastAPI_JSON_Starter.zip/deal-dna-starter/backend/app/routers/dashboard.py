import os
import json
from fastapi import APIRouter

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

def load_json(filename: str):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/kpis")
def get_dashboard_kpis():
    deals = load_json("deals.json")
    experiments = load_json("experiments.json")
    at_risk_deals = [d for d in deals if d["status"] == "At-Risk"]
    won_deals = [d for d in deals if d["status"] == "Won"]
    return {
        "revenue_at_risk": "₹2.4M",
        "recovery_opportunity": "₹1.1M",
        "active_experiments": len([e for e in experiments if e["status"] == "Running"]),
        "total_pipeline_inr": sum(d["quoted_value_inr"] for d in deals),
        "won_revenue_inr": sum(d["final_booked_inr"] for d in won_deals),
        "win_rate": "60%",
        "at_risk_count": len(at_risk_deals),
        "total_deals": len(deals)
    }

@router.get("/screens")
def get_all_screens():
    return load_json("screens.json")

@router.get("/screens/{screen_id}")
def get_screen_by_id(screen_id: str):
    screens = load_json("screens.json")
    for s in screens:
        if s["id"] == screen_id.zfill(2):
            return s
    return {"error": "Screen not found"}
