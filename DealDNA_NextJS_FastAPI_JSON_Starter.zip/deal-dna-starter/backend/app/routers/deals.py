import os
import json
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/deals", tags=["Deals"])

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

def load_json(filename: str):
    with open(os.path.join(DATA_DIR, filename), "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("")
def list_deals(status: str = None, project: str = None):
    deals = load_json("deals.json")
    if status:
        deals = [d for d in deals if d["status"].lower() == status.lower()]
    if project and project != "All projects":
        deals = [d for d in deals if d["project"].lower() == project.lower()]
    return deals

@router.get("/{deal_id}")
def get_deal_details(deal_id: str):
    deals = load_json("deals.json")
    events = load_json("events.json")
    interventions = load_json("interventions.json")
    
    deal = next((d for d in deals if d["deal_id"] == deal_id), None)
    if not deal:
        raise HTTPException(status_code=404, detail="Deal not found")
        
    deal_events = [e for e in events if e["deal_id"] == deal_id]
    deal_interventions = [i for i in interventions if i["deal_id"] == deal_id]
    
    return {
        "deal": deal,
        "events": deal_events,
        "interventions": deal_interventions,
        "root_cause": {
            "primary_cause": "Follow-up gap after site visit",
            "contributing_factor": "Price objection unresolved",
            "evidence": [
                "6 days since meaningful contact",
                "Buyer asked for revised payment plan"
            ],
            "confidence": "82%",
            "recommended_next_step": "Structured finance conversation"
        }
    }
