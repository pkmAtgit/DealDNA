import MetricCard from "@/components/MetricCard";
import RightRailInsight from "@/components/RightRailInsight";
import { fetchFromAPI } from "@/lib/api";
import Link from "next/link";

export default async function DealDetailPage({ params }: { params: { id: string } }) {
  const data = await fetchFromAPI(`/api/deals/${params.id}`, {
    deal: {
      deal_id: params.id,
      project: "Riverside Tower",
      client_name: "Rajesh Sharma",
      stage: "Closing",
      days_in_stage: 45,
      quoted_value_inr: 12500000,
      current_probability: 32,
      previous_probability: 51,
      owner: "Michael Torres",
    },
    events: [
      { event_id: "EVT-101", description: "12 Sep · Site visit completed · CRM · Positive" },
      { event_id: "EVT-102", description: "15 Sep · Price objection recorded · Call note · Negative" },
      { event_id: "EVT-103", description: "18 Sep · No follow-up for 6 days · CRM · Negative" },
      { event_id: "EVT-104", description: "21 Sep · Finance options sent · Email · Positive" },
    ],
    root_cause: {
      primary_cause: "Follow-up gap after site visit",
      contributing_factor: "Price objection unresolved",
      evidence: ["6 days since meaningful contact", "Buyer asked for revised payment plan"],
      confidence: "82%",
      recommended_next_step: "Structured finance conversation",
    },
  });

  const { deal, events, root_cause } = data;

  return (
    <div>
      <div className="mb-5 flex justify-between items-center border-b border-slate-200 pb-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">
            05–07. Deal Details, Event Timeline & Root Cause
          </h1>
          <p className="text-xs text-slate-500">
            {deal.project} · {deal.deal_id} ({deal.client_name}) · SCREENS 05, 06, 07 & 16
          </p>
        </div>
        <Link
          href="/interventions"
          className="bg-[#1967fe] text-white text-xs font-semibold px-4 py-2 rounded hover:bg-blue-700"
        >
          Recommended Intervention (Screen 08) →
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-5">
          <div className="grid grid-cols-3 gap-4">
            <MetricCard value={`${deal.current_probability}%`} label="Current probability" />
            <MetricCard value="₹4.8M" label="Expected value" />
            <MetricCard value={`${deal.days_in_stage} days`} label="In current stage" />
          </div>

          {/* Screen 05 Summary */}
          <div className="bg-white border border-slate-200 rounded-md p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              SCREEN 05 · DEAL OVERVIEW
            </div>
            <ul className="list-disc pl-5 space-y-2 text-sm text-slate-800">
              <li>Current probability: <strong>{deal.current_probability}%</strong> · Previous: {deal.previous_probability || 51}%</li>
              <li>Stage: <strong>{deal.stage}</strong> · Days in stage: {deal.days_in_stage}</li>
              <li>Owner: <strong>{deal.owner}</strong></li>
            </ul>
          </div>

          {/* Screen 06 Event Timeline */}
          <div className="bg-white border border-slate-200 rounded-md p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              SCREEN 06 · CHRONOLOGICAL EVENT TIMELINE
            </div>
            <ul className="list-disc pl-5 space-y-2 text-sm text-slate-800">
              {events.map((e: any) => (
                <li key={e.event_id}>{e.description}</li>
              ))}
            </ul>
          </div>

          {/* Screen 07 Root Cause Analysis */}
          <div className="bg-white border border-slate-200 rounded-md p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              SCREEN 07 · ROOT CAUSE ANALYSIS (EXPLAINABLE AI)
            </div>
            <ul className="list-disc pl-5 space-y-2 text-sm text-slate-800">
              <li><strong>Primary cause:</strong> {root_cause.primary_cause}</li>
              <li><strong>Contributing factor:</strong> {root_cause.contributing_factor}</li>
              {root_cause.evidence.map((ev: string, i: number) => (
                <li key={i}><strong>Evidence:</strong> {ev}</li>
              ))}
              <li><strong>Confidence:</strong> {root_cause.confidence} (illustrative)</li>
              <li><strong>Recommended next step:</strong> {root_cause.recommended_next_step}</li>
            </ul>
          </div>
        </div>

        <RightRailInsight insight="Understand deal health, supporting evidence, and likely causes rather than a black-box score." />
      </div>
    </div>
  );
}
