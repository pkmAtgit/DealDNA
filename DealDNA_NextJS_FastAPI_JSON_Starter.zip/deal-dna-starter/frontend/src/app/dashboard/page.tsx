import MetricCard from "@/components/MetricCard";
import RightRailInsight from "@/components/RightRailInsight";
import { fetchFromAPI } from "@/lib/api";
import Link from "next/link";

export default async function DashboardPage() {
  const kpis = await fetchFromAPI("/api/dashboard/kpis", {
    revenue_at_risk: "₹2.4M",
    recovery_opportunity: "₹1.1M",
    active_experiments: 6,
  });

  return (
    <div>
      <div className="mb-5 flex justify-between items-center border-b border-slate-200 pb-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">02. Command Center</h1>
          <p className="text-xs text-slate-500">Good morning, Sarah · SCREEN 02 / 20</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-5">
          <div className="grid grid-cols-3 gap-4">
            <MetricCard value={kpis.revenue_at_risk} label="Revenue at risk" />
            <MetricCard value={kpis.recovery_opportunity} label="Recovery opportunity" />
            <MetricCard value={String(kpis.active_experiments)} label="Active experiments" />
          </div>

          <div className="bg-white border border-slate-200 rounded-md p-6">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">
              WORKSPACE
            </div>
            <ul className="list-disc pl-5 space-y-3 text-sm text-slate-800">
              <li>Revenue at risk: <strong>{kpis.revenue_at_risk}</strong></li>
              <li>Recovery opportunity: <strong>{kpis.recovery_opportunity}</strong></li>
              <li>Active experiments: <strong>{kpis.active_experiments}</strong></li>
              <li>Revenue trend by month</li>
              <li>Deal health distribution (60% Win rate baseline across 10 synthetic deals)</li>
              <li>
                Top interventions and priority alerts —{" "}
                <Link href="/revenue-risk" className="text-[#1967fe] underline font-medium">
                  View Revenue at Risk Table →
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <RightRailInsight insight="Executive snapshot with urgent actions first." />
      </div>
    </div>
  );
}
